<?php
// ARRAY JUDUL
$arrJudul = ['No', 'Nama', 'Nilai', 'Keterangan'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 2 Laravel</title>
</head>

<body>
    <h1>Data Nilai Siswa</h1>
    <table border="1">
        <thead>
            <tr>
                <?php
                foreach ($arrJudul as $jdl) {
                ?>
                    <th><?= $jdl ?></th>
                <?php } ?>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            foreach ($siswa as $sw) {
                //KETERANGAN
                $ket = ($sw['nilai'] >= 60) ? 'Lulus' : 'Gagal';
            ?>
                <tr>
                    <td><?= $no ?></td>
                    <td><?= $sw['nama'] ?></td>
                    <td><?= $sw['nilai'] ?></td>
                    <td><?= $ket ?></td>
                </tr>
            <?php
                $no++;
            }
            ?>
        </tbody>
    </table>

</body>

</html>